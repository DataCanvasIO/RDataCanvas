RDataCanvas
===========

Basic runtime support for datacanvas.io
