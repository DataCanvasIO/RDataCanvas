#' RDataCanvas.
#'
#' @name RDataCanvas
#' @docType package
NULL
