library(testthat)
library(RDataCanvas)

test_check("RDataCanvas")
